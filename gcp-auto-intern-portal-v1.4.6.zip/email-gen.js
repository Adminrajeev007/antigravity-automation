/**
 * Random email generator (additive).
 *
 * Domains: the list supplied by the user.
 * Names: Hindu / Muslim / Sikh / Christian first + last names, mixed into
 * combinations, plus a 4-digit year of birth. A persistent history and a
 * collision suffix guarantee no two generated emails in this profile repeat.
 */
(function () {
  var G = typeof self !== "undefined" ? self : (typeof window !== "undefined" ? window : this);
  var DOMAINS = [
    "fireshipp.com", "apphive.org", "bytevolt.org", "datasynth.org",
    "innoloom.org", "innovanta.org", "logicquest.org", "nexaravox.org",
    "techlance.org", "techlura.org", "technexishub.org", "techsera.org",
    "techvance.org", "virova.org", "voltnest.org", "zyntek.org",
    "algoflick.org", "algonimbus.org", "algoquanta.org", "algostrive.org",
    "algovertex.org", "algovortex.org", "bitluxe.org", "bitspry.org",
    "bitvanta.org", "bitzenith.org", "bytevista.org", "codeblink.org",
    "codeflect.org", "codemeld.org", "codeplexus.org", "corecrux.org",
    "corenimbus.org", "corequanta.org", "corevertex.org", "corevireo.org",
    "cyberluxe.org", "cybervanta.org", "devblink.org", "devluxe.org",
    "devvertex.org", "scriptblink.org", "scriptglint.org", "scriptquanta.org",
    "scriptsprint.org", "technimbus.org", "algoglide.org", "algoglint.org",
    "algoluxe.org", "algostream.org", "algostride.org", "algovibe.org",
    "bitmeld.org", "bitstrive.org", "bytecrafty.org", "byteluxe.org",
    "bytevibe.org", "bytezenith.org", "codecrux.org", "codestride.org",
    "coreglint.org", "corequest.org", "cyberstrive.org", "dataglint.org",
    "devglow.org", "devmosaic.org", "devnimble.org", "devstride.org",
    "devvibe.org", "netfuze.org", "netnexa.org", "netquill.org",
    "netspry.org", "netstride.org", "scriptcrux.org", "scriptglide.org",
    "algohivehub.org", "algoloom.org", "algomatrix.org", "algonesthub.org",
    "bytecraze.org", "byteglintpro.org", "bytenexus.org", "codeglyphs.org",
    "codepatna.org", "corefuze.org", "coreluxe.org", "cybercrux.org",
    "cyberfuze.org", "cyberpatna.org", "cyberquanta.org", "cybrazehub.org",
    "devaurahub.org", "devpatna.org", "devsparkle.org", "devspectra.org",
    "logichive.org", "netluxe.org", "patnacyber.org", "patnadev.org",
    "patnatech.org", "scriptnesthub.org", "scriptvista.org", "techcrysta.org",
    "technesthub.org", "techvireo.org", "algentis.org", "algocrate.org",
    "algocrux.org", "algoforgenet.org", "algozen.org", "algvex.org",
    "bitglintnet.org", "bithatch.org", "bytepulsenet.org", "cryptixis.org",
    "cybermeld.org", "cybernestnet.org", "cybranta.org", "cybrantix.org",
    "cybrillo.org", "cybrova.org", "devsyte.org", "devvanta.org",
    "netcrate.org", "netvista.org", "scripthatch.org", "scriptix.org",
    "scriptnestnet.org", "scriptnexus.org", "scriptpulsenet.org", "techcrate.org",
    "techpulsenet.org", "techspry.org", "techstra.org", "techvex.org",
    "algoblink.org", "algoglow.org", "algomint.org", "algoquill.org",
    "algosynth.org", "algozenith.org", "bitcrux.org", "bitglide.org",
    "bitpulsenet.org", "bitsynth.org", "bitvortex.org", "bytefuze.org",
    "byteglint.org", "bytesynth.org", "codeglide.org", "codeglow.org",
    "codemosaic.org", "codenimbus.org", "codevireo.org", "corezenith.org",
    "cyberglint.org", "cyberquill.org", "devcrest.org", "devglint.org",
    "devhatch.org", "netsynth.org", "scriptloom.org", "scriptnest.org",
    "techriven.org", "algofuse.org", "algohive.org", "algonimble.org",
    "algospark.org", "algospry.org", "bitcrypta.org", "bytecrest.org",
    "byteglide.org", "bytequanta.org", "bytesummit.org", "bytevortex.org",
    "codeflick.org", "codespritz.org", "coreaura.org", "corenimble.org",
    "coresynth.org", "cyberfluent.org", "cybermint.org", "cybernovae.org",
    "cybervibe.org", "devcrux.org"
  ];

  var FIRST = {
    hindu: [
      "aarav", "vivaan", "aditya", "arjun", "rohan", "rahul", "karan",
      "nikhil", "sanjay", "vikram", "deepak", "manish", "suresh", "ramesh",
      "amit", "rajesh", "ananya", "priya", "neha", "pooja", "sneha", "kavya",
      "meera", "divya", "aarti", "ishita", "riya", "shreya", "anjali", "sunita"
    ],
    muslim: [
      "ayaan", "imran", "zaid", "faizan", "arif", "salman", "farhan", "irfan",
      "adnan", "sameer", "bilal", "usman", "tariq", "rizwan", "ayesha",
      "fatima", "zara", "sana", "rida", "nida", "hina", "mariam", "alina",
      "iqra", "shabnam", "noor", "amna", "huma", "sadia", "zoya"
    ],
    sikh: [
      "gurpreet", "harpreet", "jaspreet", "manpreet", "navdeep", "amrit",
      "jaskaran", "arjan", "gagan", "prabhjot", "tejinder", "sukhwinder",
      "harjot", "meet", "ekam", "simran", "kiran", "raman", "jasleen",
      "gurleen", "navneet", "harleen", "manjot", "seerat", "jasnoor"
    ],
    christian: [
      "john", "david", "michael", "daniel", "joseph", "thomas", "peter",
      "james", "samuel", "joshua", "vincent", "anthony", "george", "paul",
      "steven", "maria", "anna", "grace", "mary", "sarah", "rebecca",
      "rachel", "elizabeth", "christina", "angela", "julia", "sophia", "emily"
    ]
  };

  var LAST = {
    hindu: [
      "sharma", "verma", "gupta", "agarwal", "singh", "yadav", "mishra",
      "pandey", "joshi", "nair", "reddy", "rao", "iyer", "mehta", "shah",
      "patel", "chauhan", "tiwari", "bhat", "desai"
    ],
    muslim: [
      "khan", "ahmed", "ali", "hussain", "sheikh", "syed", "ansari",
      "qureshi", "siddiqui", "shaikh", "mirza", "malik", "pathan",
      "farooqui", "rizvi"
    ],
    sikh: [
      "singh", "kaur", "gill", "sandhu", "grewal", "dhillon", "bajwa",
      "sidhu", "randhawa", "mann", "brar", "sekhon"
    ],
    christian: [
      "fernandes", "dsouza", "pereira", "rodrigues", "thomas", "mathew",
      "george", "joseph", "jacob", "john", "williams", "brown", "taylor",
      "pinto", "lobo", "sequeira"
    ]
  };

  var GROUPS = ["hindu", "muslim", "sikh", "christian"];

  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function clean(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, ""); }

  function randomLocal(used) {
    for (var attempt = 0; attempt < 80; attempt++) {
      var firstGroup = pick(GROUPS);
      var lastGroup = pick(GROUPS); // mixed-culture combo
      var first = clean(pick(FIRST[firstGroup]));
      var last = clean(pick(LAST[lastGroup]));
      var year = 1985 + Math.floor(Math.random() * 20); // 1985-2004
      var base = first + "." + last + year;
      var candidates = [
        base,
        first + last + year,
        first + "." + last + "." + year,
        first + last + year + Math.floor(10 + Math.random() * 90)
      ];
      for (var i = 0; i < candidates.length; i++) {
        if (!used.has(candidates[i])) return candidates[i];
      }
    }
    return "user" + Date.now() + Math.floor(Math.random() * 1000);
  }

  // Returns a full email guaranteed not to be in `used` (a Set of lowercased emails).
  G.gcpRandomEmail = function (used) {
    var set = used instanceof Set ? used : new Set(used || []);
    var local = randomLocal(set);
    var domain = pick(DOMAINS);
    var email = local + "@" + domain;
    var guard = 0;
    while (set.has(email.toLowerCase()) && guard < 100) {
      domain = pick(DOMAINS);
      email = local + "@" + domain;
      guard += 1;
    }
    if (set.has(email.toLowerCase())) {
      email = local + Math.floor(1000 + Math.random() * 9000) + "@" + pick(DOMAINS);
    }
    return email;
  };

  G.gcpEmailDomains = DOMAINS;
})();
