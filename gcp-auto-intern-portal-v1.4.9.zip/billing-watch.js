/**
 * Billing watcher (additive).
 *
 * When the signup flow reaches the GCP billing page, upsert the current email
 * into the Sheet (action=qr) so it is recorded before a QR is generated. This
 * does NOT delete the profile; deletion still happens on QR / failure.
 */
(function () {
  if (window.top !== window) return;

  var firedFor = "";

  function isBilling() {
    var u = String(location.href || "");
    return /\/freetrial/i.test(u) && /billing/i.test(u);
  }

  async function maybe() {
    if (!isBilling()) return;
    var u = String(location.href || "");
    if (firedFor === u) return;
    firedFor = u;

    try {
      var s = await chrome.storage.local.get(["interns", "currentIndex"]);
      var cur = (s.interns || [])[s.currentIndex];
      if (!cur || !cur.email) return;
      try {
        chrome.runtime.sendMessage(
          { type: "FLEET_EVENT", kind: "billing", email: cur.email, at: Date.now() },
          function () { try { void chrome.runtime.lastError; } catch (e) {} }
        );
      } catch (e) {}
    } catch (e) {
      firedFor = "";
    }
  }

  maybe().catch(function () {});
  setInterval(function () { maybe().catch(function () {}); }, 1500);
})();
