/**
 * Random email generator (additive).
 *
 * Domains: the list supplied by the user.
 * Names: Hindu / Muslim / Sikh / Christian first + last names, mixed into
 * combinations, plus a 4-digit year of birth. A persistent history and a
 * collision suffix guarantee no two generated emails in this profile repeat.
 */
(function () {
  var G = typeof self !== "undefined" ? self : (typeof window !== "undefined" ? window : this);
  var DOMAINS = [
    "algentis.org", "algobeacon.org", "algoblink.org", "algocraft.org",
    "algocrafty.org", "algocrate.org", "algocrux.org", "algodyna.org",
    "algoflick.org", "algoflux.org", "algoforgenet.org", "algofuse.org",
    "algoglide.org", "algoglint.org", "algoglow.org", "algoharbor.org",
    "algohaven.org", "algohive.org", "algohivehub.org", "algoloom.org",
    "algoluxe.org", "algomatrix.org", "algomint.org", "algonest.org",
    "algonesthub.org", "algonexa.org", "algonimble.org", "algonimbus.org",
    "algoorbit.org", "algoquanta.org", "algoquill.org", "algospark.org",
    "algosprint.org", "algospry.org", "algostream.org", "algostride.org",
    "algostrive.org", "algosynth.org", "algovanta.org", "algovertex.org",
    "algovibe.org", "algovortex.org", "algozen.org", "algozenith.org",
    "algvex.org", "always4.org", "apphive.org", "astroaitech.org",
    "bitaura.org", "bitcrest.org", "bitcrux.org", "bitcrypta.org",
    "bitglide.org", "bitglintnet.org", "bithatch.org", "bitloom.org",
    "bitluxe.org", "bitmeld.org", "bitnimble.org", "bitpulsenet.org",
    "bitquill.org", "bitsprint.org", "bitsprout.org", "bitspry.org",
    "bitstrive.org", "bitsynth.org", "bitvanta.org", "bitvora.org",
    "bitvortex.org", "bitzenith.org", "bytecrafty.org", "bytecraze.org",
    "bytecrest.org", "bytecrux.org", "bytefuze.org", "byteglide.org",
    "byteglint.org", "byteglintpro.org", "byteglyph.org", "bytehatch.org",
    "byteluxe.org", "bytenexus.org", "bytenova.org", "bytepulsenet.org",
    "bytequanta.org", "bytesprint.org", "bytesummit.org", "bytesynth.org",
    "bytevanta.org", "bytevera.org", "bytevex.org", "bytevibe.org",
    "bytevista.org", "bytevolt.org", "bytevortex.org", "bytezenith.org",
    "clonessh.com", "cloudbeacon.org", "cloudlyst.org", "cloudnexis.org",
    "cloudpulsepro.com", "cloudquanta.org", "cloudstrix.org", "cloudsurge.org",
    "cloudsynth.org", "codalis.org", "codeaxiom.org", "codeblink.org",
    "codecrux.org", "codeflect.org", "codeflick.org", "codefuze.org",
    "codeglide.org", "codeglint.org", "codeglow.org", "codeglyph.org",
    "codeglyphs.org", "codehelix.org", "codelyric.org", "codemeld.org",
    "codemosaic.org", "codemotive.org", "codenimbus.org", "codeninnja.online",
    "codepatna.org", "codeplexus.org", "codequanta.org", "coderafter.org",
    "coderift.org", "codespritz.org", "codespry.org", "codestratus.org",
    "codestride.org", "codestrive.org", "codetrail.org", "codevireo.org",
    "codevox.org", "codezephyr.org", "coreaura.org", "coreblink.org",
    "corecrux.org", "corefuze.org", "coreglint.org", "coreglyph.org",
    "corehatch.org", "coreluxe.org", "coremint.org", "corenimble.org",
    "corequanta.org", "corequest.org", "coresprint.org", "coresynth.org",
    "corevertex.org", "corevireo.org", "corezenith.org", "cryptixis.org",
    "cryptvia.org", "cyberaegis.org", "cyberaxiom.org", "cybercrux.org",
    "cyberdevops.org", "cyberfleck.org", "cyberfluent.org", "cyberfuze.org",
    "cyberglide.org", "cyberglint.org", "cyberluxe.org", "cybermeld.org",
    "cybermint.org", "cybermotive.org", "cybernestnet.org", "cybernimble.org",
    "cybernovae.org", "cyberpatna.org", "cyberpulsex.com", "cyberquanta.org",
    "cyberquill.org", "cyberstrive.org", "cybersynth.org", "cybersynthx.org",
    "cybervanta.org", "cybervibe.org", "cyberzenith.org", "cybrance.org",
    "cybrant.org", "cybranta.org", "cybrantix.org", "cybraze.org",
    "cybrazehub.org", "cybrillo.org", "cybrova.org", "dataglide.org",
    "dataglint.org", "datanimble.org", "dataquill.org", "datasynth.org",
    "devaura.org", "devaurahub.org", "devaxion.org", "devaxis.org",
    "devbeacon.org", "devblink.org", "devcrest.org", "devcrux.org",
    "devglide.org", "devglint.org", "devglow.org", "devglyph.org",
    "devhalo.org", "devhatch.org", "devhaven.org", "devinnovation.org",
    "devluxe.org", "devlynx.org", "devmosaic.org", "devmotive.org",
    "devnexia.org", "devnexis.org", "devnimble.org", "devnook.org",
    "devnova.org", "devopsbeacon.org", "devopscore.org", "devopshive.org",
    "devopshub.org", "devopsia.org", "devopsiq.org", "devopsloom.org",
    "devopsnest.org", "devopsnexa.org", "devopsnimble.com", "devopspulse.org",
    "devopstrail.org", "devorbix.org", "devpatna.org", "devpulsex.org",
    "devquanta.org", "devsentry.org", "devsolis.org", "devsparkle.org",
    "devspectra.org", "devstride.org", "devsurge.org", "devsynapse.org",
    "devsynth.org", "devsynthx.org", "devsyte.org", "devvanta.org",
    "devvertex.org", "devvibe.org", "devvortex.org", "devzenith.org",
    "dnewcloud.org", "enewvission.org", "everyai4all.org", "furryx.dev",
    "geniai0.org", "hackingtect.site", "help-bot.org", "innoloom.org",
    "innovanta.org", "itnimble.org", "kuber2x.online", "kuberearn.online",
    "kuberx.online", "logichive.org", "logicquest.org", "mark-et.org",
    "mescasoft.org", "ncltek.com", "netaura.org", "netcrate.org",
    "netcrypta.org", "netfuze.org", "netglide.org", "netglint.org",
    "nethatch.org", "netloom.org", "netluxe.org", "netnexa.org",
    "netquill.org", "netsprint.org", "netspry.org", "netstride.org",
    "netsynth.org", "netvista.org", "nexaravox.org", "ngetek.com",
    "notebookllm.org", "opencodehub.org", "opshalox.org", "opslynx.org",
    "opsnexa.org", "opsnexis.org", "opsnimble.org", "opsnova.org",
    "opsspark.org", "opssynth.org", "opsvanta.org", "opsvox.org",
    "patnacyber.org", "patnadev.org", "patnatech.org", "savanahseeds.com",
    "scriptaura.org", "scriptblink.org", "scriptbloom.org", "scriptcrux.org",
    "scriptflux.org", "scriptglide.org", "scriptglint.org", "scriptglow.org",
    "scripthatch.org", "scriptix.org", "scriptloom.org", "scriptmint.org",
    "scriptnest.org", "scriptnesthub.org", "scriptnestnet.org", "scriptnexus.org",
    "scriptnimble.org", "scriptnova.org", "scriptpulsenet.org", "scriptquanta.org",
    "scriptrise.org", "scriptsprint.org", "scriptsummit.org", "scriptvanta.org",
    "scriptvibe.org", "scriptvista.org", "scriptvortex.org", "sqlpg.com",
    "techaiforum.org", "techaura.org", "techaxiom.org", "techaxion.org",
    "techbeacon.org", "techblink.org", "techcrate.org", "techcraze.org",
    "techcrest.org", "techcrysta.org", "techglyph.org", "techhalo.org",
    "techhivex.org", "techkernel.org", "techlance.org", "techlura.org",
    "techluxe.org", "techlynx.org", "techmeld.org", "technesthub.org",
    "technexa.org", "technexis.org", "technexishub.org", "technimbl.org",
    "technimble.org", "technimbus.org", "techpulsenet.org", "techquanta.org",
    "techquill.org", "techriven.org", "techsera.org", "techspry.org",
    "techstra.org", "techsynth.org", "techvance.org", "techvantax.com",
    "techvex.org", "techvireo.org", "techvra.org", "turtlecode.org",
    "virova.org", "voltnest.org", "web3tekx.com", "zyntek.org"
  ];

  var FIRST = {
    hindu: [
      "aarav", "vivaan", "aditya", "arjun", "rohan", "rahul", "karan",
      "nikhil", "sanjay", "vikram", "deepak", "manish", "suresh", "ramesh",
      "amit", "rajesh", "ananya", "priya", "neha", "pooja", "sneha", "kavya",
      "meera", "divya", "aarti", "ishita", "riya", "shreya", "anjali", "sunita"
    ],
    muslim: [
      "ayaan", "imran", "zaid", "faizan", "arif", "salman", "farhan", "irfan",
      "adnan", "sameer", "bilal", "usman", "tariq", "rizwan", "ayesha",
      "fatima", "zara", "sana", "rida", "nida", "hina", "mariam", "alina",
      "iqra", "shabnam", "noor", "amna", "huma", "sadia", "zoya"
    ],
    sikh: [
      "gurpreet", "harpreet", "jaspreet", "manpreet", "navdeep", "amrit",
      "jaskaran", "arjan", "gagan", "prabhjot", "tejinder", "sukhwinder",
      "harjot", "meet", "ekam", "simran", "kiran", "raman", "jasleen",
      "gurleen", "navneet", "harleen", "manjot", "seerat", "jasnoor"
    ],
    christian: [
      "john", "david", "michael", "daniel", "joseph", "thomas", "peter",
      "james", "samuel", "joshua", "vincent", "anthony", "george", "paul",
      "steven", "maria", "anna", "grace", "mary", "sarah", "rebecca",
      "rachel", "elizabeth", "christina", "angela", "julia", "sophia", "emily"
    ]
  };

  var LAST = {
    hindu: [
      "sharma", "verma", "gupta", "agarwal", "singh", "yadav", "mishra",
      "pandey", "joshi", "nair", "reddy", "rao", "iyer", "mehta", "shah",
      "patel", "chauhan", "tiwari", "bhat", "desai"
    ],
    muslim: [
      "khan", "ahmed", "ali", "hussain", "sheikh", "syed", "ansari",
      "qureshi", "siddiqui", "shaikh", "mirza", "malik", "pathan",
      "farooqui", "rizvi"
    ],
    sikh: [
      "singh", "kaur", "gill", "sandhu", "grewal", "dhillon", "bajwa",
      "sidhu", "randhawa", "mann", "brar", "sekhon"
    ],
    christian: [
      "fernandes", "dsouza", "pereira", "rodrigues", "thomas", "mathew",
      "george", "joseph", "jacob", "john", "williams", "brown", "taylor",
      "pinto", "lobo", "sequeira"
    ]
  };

  var GROUPS = ["hindu", "muslim", "sikh", "christian"];

  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  function clean(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, ""); }

  function randomLocal(used) {
    for (var attempt = 0; attempt < 80; attempt++) {
      var firstGroup = pick(GROUPS);
      var lastGroup = pick(GROUPS); // mixed-culture combo
      var first = clean(pick(FIRST[firstGroup]));
      var last = clean(pick(LAST[lastGroup]));
      var year = 1985 + Math.floor(Math.random() * 20); // 1985-2004
      var base = first + "." + last + year;
      var candidates = [
        base,
        first + last + year,
        first + "." + last + "." + year,
        first + last + year + Math.floor(10 + Math.random() * 90)
      ];
      for (var i = 0; i < candidates.length; i++) {
        if (!used.has(candidates[i])) return candidates[i];
      }
    }
    return "user" + Date.now() + Math.floor(Math.random() * 1000);
  }

  // Returns a full email guaranteed not to be in `used` (a Set of lowercased emails).
  G.gcpRandomEmail = function (used) {
    var set = used instanceof Set ? used : new Set(used || []);
    var local = randomLocal(set);
    var domain = pick(DOMAINS);
    var email = local + "@" + domain;
    var guard = 0;
    while (set.has(email.toLowerCase()) && guard < 100) {
      domain = pick(DOMAINS);
      email = local + "@" + domain;
      guard += 1;
    }
    if (set.has(email.toLowerCase())) {
      email = local + Math.floor(1000 + Math.random() * 9000) + "@" + pick(DOMAINS);
    }
    return email;
  };

  G.gcpEmailDomains = DOMAINS;
})();
