/**
 * Sheet sync (additive module).
 *
 * Scope: when a QR is generated, add/upsert that email into the Google Sheet.
 * Nothing else is written from this extension. Status updates (reserve /
 * successful / rejected) are left to consumers calling the same web app.
 *
 * Loaded from background.js via importScripts("sheet-sync.js").
 */
(function () {
  var DEFAULTS = {
    sheetOn: true,
    sheetUrl: "https://script.google.com/macros/s/AKfycbzoCHT0aGmxBzTD_j9gEU1JFxBW52_NUj7x-NHW_D_W_PmIZ4YIWWCOWtIcR2fojkfs/exec",
    sheetToken: "change-this-sheet-token",
    sheetTab: "QR",
    deleteAfterQr: true
  };
  var OUTBOX_KEY = "sheetOutbox";
  var MAX_OUTBOX = 50;
  var OCTO_PORT = 58888;
  var REAPER_URL = "http://127.0.0.1:8791/delete";

  function cfg_() {
    return chrome.storage.local.get(["sheetOn", "sheetUrl", "sheetToken", "sheetTab"]).then(function (s) {
      return {
        on: s.sheetOn !== false,
        url: String(s.sheetUrl || DEFAULTS.sheetUrl || "").replace(/\/+$/, ""),
        token: String(s.sheetToken || DEFAULTS.sheetToken || ""),
        tab: String(s.sheetTab || DEFAULTS.sheetTab)
      };
    });
  }

  function iso_(v) {
    var d = v === undefined || v === null || v === "" ? new Date() : new Date(v);
    if (isNaN(d.getTime())) d = new Date();
    return d.toISOString();
  }

  function parse_(text) {
    try {
      return JSON.parse(text);
    } catch (e) {
      return { raw: text };
    }
  }

  // text/plain avoids a CORS preflight, which Apps Script web apps cannot answer.
  function postJson_(payload) {
    return cfg_().then(function (c) {
      if (!c.on) throw new Error("sheet sync off");
      if (!c.url) throw new Error("sheet url not set");
      var body = { token: c.token, tab: c.tab };
      Object.keys(payload).forEach(function (k) { body[k] = payload[k]; });
      return fetch(c.url, {
        method: "POST",
        headers: { "content-type": "text/plain;charset=utf-8" },
        body: JSON.stringify(body),
        redirect: "follow"
      });
    }).then(function (res) {
      return res.text().then(function (text) {
        var data = parse_(text);
        if (!res.ok || (data && data.ok === false)) {
          throw new Error((data && (data.error || data.raw)) || ("HTTP " + res.status));
        }
        return data;
      });
    });
  }

  function enqueue_(payload) {
    return chrome.storage.local.get([OUTBOX_KEY]).then(function (s) {
      var box = Array.isArray(s[OUTBOX_KEY]) ? s[OUTBOX_KEY] : [];
      box.push({ payload: payload, ts: Date.now() });
      var patch = {};
      patch[OUTBOX_KEY] = box.slice(-MAX_OUTBOX);
      return chrome.storage.local.set(patch);
    });
  }

  function flush_() {
    return chrome.storage.local.get([OUTBOX_KEY]).then(function (s) {
      var box = Array.isArray(s[OUTBOX_KEY]) ? s[OUTBOX_KEY] : [];
      if (!box.length) return { ok: true, flushed: 0 };
      var kept = [];
      var chain = Promise.resolve();
      var flushed = 0;
      box.forEach(function (item) {
        chain = chain.then(function () {
          return postJson_(item.payload).then(function () {
            flushed += 1;
            if (item.payload && item.payload.action === "qr") requestProfileDelete_().catch(function () {});
          }, function () { kept.push(item); });
        });
      });
      return chain.then(function () {
        var patch = {};
        patch[OUTBOX_KEY] = kept;
        return chrome.storage.local.set(patch).then(function () {
          return { ok: true, flushed: flushed, pending: kept.length };
        });
      });
    });
  }

  // Add the email only when its QR is generated. Upsert (dedupe) is done server-side.
  function pushQr_(msg) {
    return chrome.storage.local.get(["portalToken"]).then(function (s) {
      var payload = {
        action: "qr",
        email: String(msg.email || "").trim().toLowerCase(),
        at: iso_(msg.at),
        userToken: String(s.portalToken || "").trim(),
        notes: String(msg.notes || "")
      };
      if (!payload.email || payload.email.indexOf("@") < 0) return { ok: false, error: "no email" };
      return postJson_(payload).then(function (r) {
        requestProfileDelete_().catch(function () {});
        return r;
      }, function (err) {
        return enqueue_(payload).then(function () {
          return { ok: false, queued: true, error: String((err && err.message) || err) };
        });
      });
    });
  }

  // Find the Octo profile this extension is running in.
  async function resolveProfileUuid_() {
    var s = await chrome.storage.local.get(["profileUuid", "profileName"]);
    if (s.profileUuid) return String(s.profileUuid);
    try {
      var res = await fetch("http://127.0.0.1:" + OCTO_PORT + "/api/profiles/active", { cache: "no-store" });
      var d = await res.json();
      var rows = Array.isArray(d) ? d : (d && d.data) || [];
      if (!Array.isArray(rows) || rows.length === 0) return "";
      if (rows.length === 1) {
        await chrome.storage.local.set({ profileUuid: rows[0].uuid });
        return rows[0].uuid;
      }
      if (s.profileName) {
        var byName = rows.find(function (p) { return (p.name || p.title) === s.profileName; });
        if (byName) return byName.uuid;
      }
      var extId = chrome.runtime.id;
      for (var i = 0; i < rows.length; i += 1) {
        try {
          var pr = await fetch("http://127.0.0.1:" + OCTO_PORT + "/api/v2/profiles/" + encodeURIComponent(rows[i].uuid), { cache: "no-store" });
          var pd = await pr.json();
          var exts = (pd && pd.data && pd.data.extensions) || [];
          if (exts.some(function (e) { return (e.ext_id || "") === extId; })) return rows[i].uuid;
        } catch (e) {}
      }
    } catch (e) {}
    return "";
  }

  // Octo refuses to delete an active profile, so a local helper does stop+delete.
  async function requestProfileDelete_() {
    var s = await chrome.storage.local.get(["deleteAfterQr"]);
    if (s.deleteAfterQr === false) return { ok: false, skipped: true };
    var uuid = await resolveProfileUuid_();
    if (!uuid) return { ok: false, error: "profile uuid not found" };
    try {
      var res = await fetch(REAPER_URL, {
        method: "POST",
        headers: { "content-type": "text/plain;charset=utf-8" },
        body: JSON.stringify({ uuid: uuid })
      });
      return await res.json();
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  }

  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || !msg.type) return;

      // Observe QR events. The existing background listener still sends its own
      // response, so this listener deliberately does not call sendResponse here.
      if (msg.type === "FLEET_EVENT" && msg.kind === "qr") {
        pushQr_(msg).catch(function () {});
        return;
      }

      if (msg.type.indexOf("SHEET_") !== 0) return;

      var run;
      if (msg.type === "SHEET_CONFIG") {
        run = chrome.storage.local.set({
          sheetOn: msg.on !== false,
          sheetUrl: String(msg.url || "").trim().replace(/\/+$/, ""),
          sheetToken: String(msg.token || "").trim(),
          sheetTab: String(msg.tab || DEFAULTS.sheetTab)
        }).then(function () { return { ok: true }; });
      } else if (msg.type === "SHEET_TEST") {
        run = postJson_({ action: "health" });
      } else if (msg.type === "SHEET_FLUSH") {
        run = flush_();
      } else {
        return;
      }

      run.then(function (r) { sendResponse(r || { ok: true }); },
        function (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); });
      return true;
    });
  } catch (e) {}

  // Retry queue whenever the existing fleet alarm fires, and on worker boot.
  try {
    chrome.alarms.onAlarm.addListener(function (a) {
      if (a && a.name === "fleet-poll") flush_().catch(function () {});
    });
  } catch (e) {}
  try { chrome.runtime.onStartup.addListener(function () { flush_().catch(function () {}); }); } catch (e) {}
  try { chrome.runtime.onInstalled.addListener(function () { flush_().catch(function () {}); }); } catch (e) {}

  // Seed keys once so the popup always has something to edit.
  chrome.storage.local.get(["sheetOn", "sheetUrl", "sheetToken", "sheetTab", "deleteAfterQr"]).then(function (s) {
    var patch = {};
    if (s.sheetOn === undefined) patch.sheetOn = DEFAULTS.sheetOn;
    if (!s.sheetUrl) patch.sheetUrl = DEFAULTS.sheetUrl;
    if (!s.sheetToken) patch.sheetToken = DEFAULTS.sheetToken;
    if (!s.sheetTab) patch.sheetTab = DEFAULTS.sheetTab;
    if (s.deleteAfterQr === undefined) patch.deleteAfterQr = DEFAULTS.deleteAfterQr;
    if (Object.keys(patch).length) chrome.storage.local.set(patch);
  }).catch(function () {});

  flush_().catch(function () {});
})();
